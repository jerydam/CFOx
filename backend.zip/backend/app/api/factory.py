"""
Factory API — deploys a new CFOx suite via CFOxFactory.deploy()
and registers the resulting treasury in the database.
"""

import os
from decimal import Decimal
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, field_validator

from ..services.web3_service import get_web3_service, Web3Service
from ..services.db_service import get_db, TreasuryDB

router = APIRouter()


# ─── Request / Response ───────────────────────────────────────────────────────

class DeployRequest(BaseModel):
    founder_address: str        # 0x — the wallet deploying (signs on frontend)
    founder_name: str
    org_name: str
    per_tx_limit: Decimal = Decimal("100")    # USD amounts; backend converts to USDC wei
    daily_limit: Decimal = Decimal("500")
    weekly_limit: Decimal = Decimal("2000")

    @field_validator("founder_address")
    @classmethod
    def validate_address(cls, v: str) -> str:
        v = v.strip()
        if not v.startswith("0x") or len(v) != 42:
            raise ValueError(f"Invalid address: {v}")
        return v.lower()


class DeployResponse(BaseModel):
    tx_hash: str
    factory_address: str
    governance_address: str
    treasury_address: str
    policy_address: str
    treasury_id: str            # DB UUID — set in NEXT_PUBLIC_TREASURY_ID


class InstanceResponse(BaseModel):
    has_instance: bool
    governance_address: str | None = None
    treasury_address: str | None = None
    policy_address: str | None = None
    treasury_id: str | None = None


# ─── Routes ───────────────────────────────────────────────────────────────────

@router.post("/deploy", response_model=DeployResponse)
async def deploy_instance(
    body: DeployRequest,
    web3: Web3Service = Depends(get_web3_service),
):
    """
    Deploy a full CFOx suite (Governance + Treasury + Policy) via the factory.
    The agent wallet submits the tx; the founder address is passed as the
    FOUNDER_ADDRESS param so governance mints 100% equity to them.
    """
    usdc_address = os.getenv("USDC_ADDRESS")
    if not usdc_address:
        raise HTTPException(status_code=500, detail="USDC_ADDRESS not configured")

    # Check if founder already has an instance
    existing = web3.get_instance(body.founder_address)
    if existing and existing["governance"] != "0x0000000000000000000000000000000000000000":
        raise HTTPException(
            status_code=409,
            detail=f"Founder already has a deployed instance: {existing['governance']}"
        )

    # USDC has 6 decimals
    per_tx_raw  = int(body.per_tx_limit  * Decimal("1e6"))
    daily_raw   = int(body.daily_limit   * Decimal("1e6"))
    weekly_raw  = int(body.weekly_limit  * Decimal("1e6"))

    result = web3.deploy_instance(
        founder_address=body.founder_address,
        founder_name=body.founder_name,
        usdc_address=usdc_address,
        per_tx_limit=per_tx_raw,
        daily_limit=daily_raw,
        weekly_limit=weekly_raw,
    )

    # Register in DB
    db = TreasuryDB(get_db())

    # Upsert org
    org = db.get_or_create_org(body.founder_address, body.org_name)

    treasury_row = db.create_treasury(
        org_id=org["id"],
        address=result["treasury_address"],
        chain_id=web3.chain_id,
        name=f"{body.org_name} Treasury",
        governance_address=result["governance_address"],
        policy_address=result["policy_address"],
        factory_address=web3.factory_address,
    )

    # Seed the founder as first member
    db.upsert_member(treasury_row["id"], body.founder_address, {
        "name": body.founder_name,
        "role": "Founder",
        "equity_weight": 10000,
        "active": True,
    })

    # Seed default policy row
    db.upsert_policy(treasury_row["id"], {
        "per_transaction_limit_usd": float(body.per_tx_limit),
        "daily_limit_usd": float(body.daily_limit),
        "weekly_limit_usd": float(body.weekly_limit),
    })

    return DeployResponse(
        tx_hash=result["tx_hash"],
        factory_address=web3.factory_address,
        governance_address=result["governance_address"],
        treasury_address=result["treasury_address"],
        policy_address=result["policy_address"],
        treasury_id=treasury_row["id"],
    )


@router.get("/instance/{founder_address}", response_model=InstanceResponse)
async def get_instance(
    founder_address: str,
    web3: Web3Service = Depends(get_web3_service),
):
    """Check if a founder already has a deployed CFOx instance."""
    try:
        data = web3.get_instance(founder_address)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    zero = "0x0000000000000000000000000000000000000000"
    if not data or data["governance"] == zero:
        return InstanceResponse(has_instance=False)

    # Look up treasury_id from DB
    db = TreasuryDB(get_db())
    treasury_row = db.get_treasury_by_address(data["treasury"])

    return InstanceResponse(
        has_instance=True,
        governance_address=data["governance"],
        treasury_address=data["treasury"],
        policy_address=data["policy"],
        treasury_id=treasury_row["id"] if treasury_row else None,
    )
